﻿/* German Translation for the iGuider plugin. */
jQuery(function($){
	$.iGuiderLang = {
		lang:'de',
		cancelText: '×',
		cancelTitle:	'Stornieren',
		hideText: 'Verstecken',
		tourMapText:'≡',
		tourMapTitle: 'Tour of Karte',
		nextTextDefault:'Nächster',
		prevTextDefault:'Zurück',
		endText:'Ende',
		contDialogTitle:'Weiter die unvollendete Tour?',
		contDialogContent:'Klicken Sie auf "Weiter" mit Schritt zu starten, auf dem das letzte Mal beendet.',
		contDialogBtnBegin:'Starten Sie von Anfang an',
		contDialogBtnContinue:'Weiter',
		introTitle:'Willkommen bei der interaktiven Tour.', 							
		introContent:'Auf dieser Tour erfahren Sie mehr über die wichtigsten Funktionen der Website.',	
		introDialogBtnStart:'Anfang',											
		introDialogBtnCancel:'Stornieren'
	}
});