﻿/* Norwegian Translation for the iGuider plugin. */
jQuery(function($){
	$.iGuiderLang = {
		lang:'nb',
		cancelText: '×',
		cancelTitle:	'Kansellere',
		hideText: 'Skjul',
		tourMapText:'≡',	
		tourMapTitle: 'Kart over tour',
		nextTextDefault:'Neste',	
		prevTextDefault:'Forrige',	
		endText:'Ferdig',
		contDialogTitle:'Fortsett den uferdige tur?',
		contDialogContent:'Klikk "Fortsett" for å starte med trinn på som ferdig sist.',
		contDialogBtnBegin:'Start fra begynnelsen',
		contDialogBtnContinue:'Fortsette',
		introTitle:'Velkommen til den interaktive turen.', 							
		introContent:'Denne turen vil fortelle deg om funksjonene i hovedsiden.',	
		introDialogBtnStart:'Start',											
		introDialogBtnCancel:'Avbryt'
	}
});