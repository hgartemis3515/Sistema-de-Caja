﻿/* Norwegian Nynorsk Translation for the iGuider plugin. */
jQuery(function($){
	$.iGuiderLang = {
		lang:'nn',
		cancelText: '×',
		cancelTitle:	'Lukk',
		hideText: 'Skjul',
		tourMapText:'≡',	
		tourMapTitle: 'Kart over tour',
		nextTextDefault:'Neste',	
		prevTextDefault:'Førre',	
		endText:'Ferdig',
		contDialogTitle: 'Fortsett den uferdige tur? ',
		contDialogContent: 'Klikk "Fortsett" for å starte med trinn på som ferdig sist gang.',
		contDialogBtnBegin: 'Start fra begynnelsen ',
		contDialogBtnContinue: 'Fortsett',
		introTitle:'Velkommen til den interaktive turen.', 							
		introContent:'Denne turen vil fortelle deg om funksjonene i hovedsiden.',	
		introDialogBtnStart:'Start',											
		introDialogBtnCancel:'Avbryt'
	}
});