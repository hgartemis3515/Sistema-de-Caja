﻿/* Russian Translation for the iGuider plugin. */
jQuery(function($){
	$.iGuiderLang = {
		lang:'ru',
		cancelText: '×',
		cancelTitle:	'Прервать',
		hideText: 'Скрыть карту',
		tourMapText:'≡',	
		tourMapTitle: 'Карта тура',
		nextTextDefault:'Дальше',	
		prevTextDefault:'Назад',	
		endText:'Закончить тур',
		contDialogTitle: 'Продолжить незаконченный тур?',
		contDialogContent: 'Нажмите кнопку "Продолжить", чтобы начать с шага, на котором остановились в прошлый раз.',
		contDialogBtnBegin: 'Начать с начала',
		contDialogBtnContinue: 'Продолжить',
		introTitle:'Добро пожаловать в интерактивный тур.', 							
		introContent:'Этот тур расскажет вам об основных функциях сайта.',	
		introDialogBtnStart:'Начать',											
		introDialogBtnCancel:'Отмена'
	}
});