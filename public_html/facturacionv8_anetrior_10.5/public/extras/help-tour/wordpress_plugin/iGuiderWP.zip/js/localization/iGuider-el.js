﻿/* Greek Translation for the iGuider plugin. */
jQuery(function($){
	$.iGuiderLang = {
		lang:'el',
		cancelText: '×',
		cancelTitle:	'Ματαίωση',
		hideText: 'Κρύβω',
		tourMapText:'≡',
		tourMapTitle: 'Περιοδεία του χάρτη',
		nextTextDefault:'Επόμενος',
		prevTextDefault:'Προηγούμενος',
		endText:'Τέλος',
		contDialogTitle:'Συνεχίστε το ημιτελές περιοδεία;',
		contDialogContent:'Κάντε κλικ στο κουμπί "Συνέχεια" για να ξεκινήσετε με το βήμα στο οποίο τερμάτισε τελευταία φορά.',
		contDialogBtnBegin:'Ξεκινήστε από την αρχή',
		contDialogBtnContinue:'Συνέχεια',
		introTitle:'Καλώς ήρθατε στη διαδραστική περιήγηση.', 							
		introContent:'Αυτή η περιήγηση θα σας ενημερώσει για τις κύριες λειτουργίες του ιστότοπου.',	
		introDialogBtnStart:'Αρχή',											
		introDialogBtnCancel:'Ματαίωση'
	}
});