﻿/* Korean Translation for the iGuider plugin. */
jQuery(function($){
	$.iGuiderLang = {
		lang:'ko',
		cancelText: '×',
		cancelTitle:	'취소하다',
		hideText: '숨는 장소',
		tourMapText:'≡',	
		tourMapTitle: '여행지도',
		nextTextDefault:'다음 것',	
		prevTextDefault:'너무 이른',	
		endText:'끝난',
		contDialogTitle: '미완성 여행을 계속 하시겠습니까?',
		contDialogContent: '마지막을 완성하는 단계로 시작 "계속" 을 클릭합니다.',
		contDialogBtnBegin: '처음부터 시작',
		contDialogBtnContinue : '계속',
		introTitle:'대화식 둘러보기에 오신 것을 환영합니다', 							
		introContent:'이 둘러보기는 주요 사이트 기능에 대해 알려줍니다',	
		introDialogBtnStart:'스타트',											
		introDialogBtnCancel:'취소'
	}
});