﻿/* Khmer Translation for the iGuider plugin. */
jQuery(function($){
	$.iGuiderLang = {
		lang:'km',
		cancelText: '×',
		cancelTitle:	'បោះបង់',
		hideText: 'លាក់',
		tourMapText:'≡',	
		tourMapTitle: 'ផែនទី',
		nextTextDefault:'បន្ទាប់',	
		prevTextDefault:'មុន',	
		endText:'ធ្វើរួច',
		contDialogTitle: 'បន្តដំណើរទស្សនកិច្ចមិនទាន់បានបញ្ចប់នោះ? ',
		contDialogContent: 'ចុច "បន្ត" ដើម្បីចាប់ផ្តើមដោយជំហាននៅលើដែលបានបញ្ចប់ការពេលវេលាចុងក្រោយ។',
		contDialogBtnBegin: 'ការចាប់ផ្តើមតាំងពីដើមដំបូង',
		contDialogBtnContinue: 'បន្ត',
		introTitle:'ស្វាគមន៍មកកាន់ដំណើរកំសាន្តអន្តរកម្ម។', 							
		introContent:'ដំណើរកម្សាន្តនេះនឹងប្រាប់អ្នកអំពីមុខងារសំខាន់របស់គេហទំព័រ។',	
		introDialogBtnStart:'ចាប់ផ្តើម',											
		introDialogBtnCancel:'បោះបង់'
	}
});