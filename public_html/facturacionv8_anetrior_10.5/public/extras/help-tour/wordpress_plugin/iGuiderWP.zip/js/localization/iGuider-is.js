﻿/* Icelandic Translation for the iGuider plugin. */
jQuery(function($){
	$.iGuiderLang = {
		lang:'is',
		cancelText: '×',
		cancelTitle: 'Hætta',
		hideText: 'fela',
		tourMapText:'≡',	
		tourMapTitle: 'Kort af ferð',
		nextTextDefault:'Næsti',	
		prevTextDefault:'Fyrri',	
		endText:'Lokið',
		contDialogTitle: 'Áfram óunnið ferð?',
		contDialogContent: 'Smelltu á "Halda áfram" til að byrja með skref sem lauk síðasta sinn. ',
		contDialogBtnBegin: 'Byrja frá byrjun ',
		contDialogBtnContinue: 'Halda áfram',
		introTitle:'Velkomin á gagnvirka ferðina.', 							
		introContent:'Þessi ferð mun segja þér um helstu virkni vefsvæðisins.',	
		introDialogBtnStart:'Byrja',											
		introDialogBtnCancel:'Hætta'
	}
});