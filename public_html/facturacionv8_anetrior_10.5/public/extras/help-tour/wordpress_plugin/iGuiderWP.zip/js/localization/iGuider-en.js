﻿/* English Translation for the iGuider plugin. */
jQuery(function($){
	$.iGuiderLang = {
		lang:'en',
		cancelText: '×',
		cancelTitle: 'Cancel Tour',
		hideText: 'Hide Tour Map',
		tourMapText:'≡',	
		tourMapTitle: 'Tour Map',
		nextTextDefault:'Next',	
		prevTextDefault:'Prev',	
		endText:'End Tour',
		contDialogTitle:'Continue the unfinished tour?',
		contDialogContent:'Click "Continue" to start with step on which finished last time.',
		contDialogBtnBegin:'Start over',
		contDialogBtnContinue:'Continue',
		introTitle:'Welcome to the interactive tour', 							
		introContent:'This tour will tell you about the main site functionalities',	
		introDialogBtnStart:'Start',											
		introDialogBtnCancel:'Cancel'
	}
});