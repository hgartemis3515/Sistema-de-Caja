﻿/* Chinese Translation for the iGuider plugin. */
jQuery(function($){
	$.iGuiderLang = {
		lang:'zh',
		cancelText: '×',
		cancelTitle:	'取消遊覽',
		hideText: '隱藏',
		tourMapText:'≡',	
		tourMapTitle: '地圖之旅',
		nextTextDefault:'下月 &#x3E;',	
		prevTextDefault:'&#x3C; 上月',	
		endText:'結束',
		contDialogTitle:'繼續未完成的旅遊？',
		contDialogContent:'點擊"繼續" 開始與步上最後一次完成。',
		contDialogBtnBegin:'從年初開始',
		contDialogBtnContinue:'繼續',
		introTitle:'歡迎來到互動之旅', 							
		introContent:'這個旅程會告訴你主要的網站功能',	
		introDialogBtnStart:'開始',											
		introDialogBtnCancel:'取消'
	}
});